// Task 4 (second one): Find the intersection of two linked lists
// Roll no: l253022

#include <iostream>
#include <stdexcept>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int d) : data(d), next(nullptr) {}
};

// keeps asking until the user types a whole number inside [lo, hi]
int readInt(const char* prompt, int lo, int hi) {
    int value;
    while (true) {
        cout << prompt;
        cin >> value;
        if (cin.eof()) throw runtime_error("input stream closed");
        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Please type a whole number" << endl;
            continue;
        }
        cin.ignore(1000, '\n');
        if (value < lo || value > hi) {
            cout << "Value must be between " << lo << " and " << hi << endl;
            continue;
        }
        return value;
    }
}


const int MAX_LEN = 10000;

class LinkedList {
private:
    Node* head;
    Node* tail;
    int size;
    Node* joinPoint;   // first node this list shares with another list, if any

public:
    LinkedList() : head(nullptr), tail(nullptr), size(0), joinPoint(nullptr) {}
    ~LinkedList() { clear(); }
    LinkedList(const LinkedList&) = delete;
    LinkedList& operator=(const LinkedList&) = delete;

    void append(int v) {
        if (joinPoint) throw runtime_error("this list is joined, reset the lists first");
        if (size >= MAX_LEN) throw runtime_error("list is full, max 10000 nodes");
        Node* n = new Node(v);
        if (!head) head = tail = n;
        else { tail->next = n; tail = n; }
        size++;
    }

    // stops at the shared part so the other list's nodes are not freed twice
    void clear() {
        while (head && head != joinPoint) {
            Node* t = head;
            head = head->next;
            delete t;
        }
        head = tail = nullptr;
        joinPoint = nullptr;
        size = 0;
    }

    // links the end of this list to an existing node, no new nodes are made
    void attachTo(Node* target) {
        if (!head) head = target;
        else tail->next = target;
        joinPoint = target;
        size = 0;
        for (Node* c = head; c; c = c->next) size++;
    }

    bool isEmpty() const { return head == nullptr; }
    bool isJoined() const { return joinPoint != nullptr; }
    Node* getHead() const { return head; }
    int getSize() const { return size; }

    void display() const {
        if (!head) { cout << "(empty)" << endl; return; }
        for (Node* c = head; c; c = c->next)
            cout << c->data << (c->next ? " -> " : "");
        cout << endl;
    }
};

// B joins A at the k-th node of A (1 based), returns false if A is too short
bool makeIntersection(LinkedList& a, LinkedList& b, int k) {
    if (k < 1) throw runtime_error("k must be at least 1");
    if (b.isJoined()) throw runtime_error("B is already joined to A");
    Node* kth = a.getHead();
    for (int i = 1; i < k && kth; i++) kth = kth->next;
    if (!kth) return false;
    b.attachTo(kth);
    return true;
}

void fillList(LinkedList& l) {
    int n = readInt("How many elements (0 to 10000): ", 0, MAX_LEN);
    l.clear();
    for (int i = 1; i <= n; i++) {
        cout << "Element " << i << ": ";
        l.append(readInt("", -2147483647, 2147483647));
    }
}

LinkedList& pickList(LinkedList& a, LinkedList& b) {
    return readInt("Which list, 1 for A and 2 for B: ", 1, 2) == 1 ? a : b;
}

void resetBoth(LinkedList& a, LinkedList& b) {
    b.clear();   // B first, since it may be borrowing nodes from A
    a.clear();
}

int countNodes(const Node* h) {
    int n = 0;
    for (; h; h = h->next) n++;
    return n;
}

// skip the extra nodes of the longer list, then walk both together
Node* findIntersection(const LinkedList& a, const LinkedList& b) {
    Node* pa = a.getHead();
    Node* pb = b.getHead();
    int la = countNodes(pa);
    int lb = countNodes(pb);
    while (la > lb) { pa = pa->next; la--; }
    while (lb > la) { pb = pb->next; lb--; }
    while (pa != pb) {
        pa = pa->next;
        pb = pb->next;
    }
    return pa;   // null when they never meet
}

int main() {
    LinkedList a, b;
    int choice = -1;
    while (choice != 0) {
        try {
            cout << endl;
            cout << "Find the intersection of two linked lists" << endl;
            cout << "1. Fill a list" << endl;
            cout << "2. Append one value to a list" << endl;
            cout << "3. Display lists" << endl;
            cout << "4. Join B to A at the k-th node (for testing)" << endl;
            cout << "5. Find intersection" << endl;
            cout << "6. Reset both lists" << endl;
            cout << "0. Exit" << endl;
            choice = readInt("Choice: ", 0, 6);
            switch (choice) {
            case 1:
                if (b.isJoined()) throw runtime_error("lists are joined, reset them first");
                fillList(pickList(a, b));
                break;
            case 2:
                if (b.isJoined()) throw runtime_error("lists are joined, reset them first");
                pickList(a, b).append(readInt("Value: ", -2147483647, 2147483647));
                break;
            case 3:
                cout << "A: "; a.display();
                cout << "B: "; b.display();
                break;
            case 4: {
                int k = readInt("Enter k: ", 1, 2147483647);
                if (makeIntersection(a, b, k)) cout << "Lists are joined now" << endl;
                else cout << "Could not join, A has fewer than " << k << " nodes" << endl;
                break;
            }
            case 5: {
                Node* meet = findIntersection(a, b);
                if (meet) cout << "They intersect at the node with value " << meet->data << endl;
                else cout << "The lists do not intersect" << endl;
                break;
            }
            case 6:
                resetBoth(a, b);
                cout << "Both lists are empty now" << endl;
                break;
            }
        } catch (const runtime_error& e) {
            cout << "Error: " << e.what() << endl;
            if (cin.eof()) break;
        }
    }
    cout << "Bye" << endl;
    return 0;
}
